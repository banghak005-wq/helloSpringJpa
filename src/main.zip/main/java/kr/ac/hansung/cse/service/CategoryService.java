package kr.ac.hansung.cse.service;

import kr.ac.hansung.cse.model.Category;
import kr.ac.hansung.cse.model.Product;
import kr.ac.hansung.cse.repository.CategoryRepository;
import kr.ac.hansung.cse.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
public class CategoryService {
    // 1. 카테고리 전체 목록 조회
    CategoryRepository categoryRepository = new CategoryRepository();
    ProductRepository  productRepository = new ProductRepository();
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    // 2. 카테고리 등록
    @Transactional
    public Category createCategory(Category category) {
        return categoryRepository.save(category);
    }

    // 3. 카테고리 삭제 (트릭 포함)
    @Transactional
    public void deleteCategory(Long id) {
        // 상품 리포지토리에서 해당 카테고리 ID를 가진 상품이 있는지 카운트
        // (이 메소드는 ProductRepository에 정의되어 있어야 함)
        long productCount = productRepository.countByCategoryId(id); 

        if (productCount > 0) {
            throw new IllegalStateException("해당 카테고리에 속한 상품이 있어 삭제할 수 없습니다.");
        }
        categoryRepository.delete(id);
    }
}
